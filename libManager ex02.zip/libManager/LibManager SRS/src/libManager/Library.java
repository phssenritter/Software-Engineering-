package libManager;

public class Library {
	
}
